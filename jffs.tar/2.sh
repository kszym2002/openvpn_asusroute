PS4IP=192.168.50.233

iptables -t mangle -F
iptables -t mangle -X

iptables -t mangle -A PREROUTING -j CONNMARK --restore-mark
iptables -t mangle -A PREROUTING -m mark --mark 1 -j ACCEPT
iptables -t mangle -A PREROUTING -s $PS4IP  -m set ! --match-set chnroute dst -j MARK --set-mark 1
iptables -t mangle -A PREROUTING -j CONNMARK --save-mark

if ! iptables -t nat -A POSTROUTING -o tun11 -j MASQUERADE 2>/dev/null; then
    iptables -t nat -A POSTROUTING -o tun11 -j MASQUERADE
else
    echo "info: nat rule already exists"
fi

  service restart_dnsmasq
