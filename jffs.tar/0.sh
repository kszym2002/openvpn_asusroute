#!/bin/sh
ipset create chnroute hash:net
for ip in $(cat '/jffs/route/route.list'); do
    ipset add chnroute $ip
done