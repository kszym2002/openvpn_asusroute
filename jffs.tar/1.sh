#!/bin/bash

TUNIP="192.168.66.1"
ROUTEIP="192.168.50.1"
ROUTEEER="192.168.50.0/24"
TUNDEV="tun11"
TUNPEER=`route -n | grep $TUNDEV| awk '{ print $1 }'`
TABLE_ID=100 # ·�ɱ� ID

echo "TUNIP: $TUNIP"
echo "ROUTEIP: $ROUTEIP"
echo "ROUTEEER: $ROUTEEER"
echo "TUNDEV: $TUNDEV"
echo "TUNPEER: $TUNPEER"
echo "TABLE_ID: $TABLE_ID"


ip rule del from all fwmark 0x1 
ip rule del from $TUNIP table $TABLE_ID
ip route flush table $TABLE_ID

ip route add table $TABLE_ID default dev $TUNDEV via $TUNIP

ip route add table $TABLE_ID $ROUTEEER dev br0 src $ROUTEIP

ip route flush cache

ip rule add from $TUNIP table $TABLE_ID

ip rule add fwmark 1 table $TABLE_ID
echo 2 > /proc/sys/net/ipv4/conf/$TUNDEV/rp_filter